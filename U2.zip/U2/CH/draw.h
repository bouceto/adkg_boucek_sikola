#ifndef DRAW_H
#define DRAW_H

#include <QWidget>
#include <vector>

class Draw : public QWidget
{
    Q_OBJECT

private:
    QPolygon points;
    QPolygon ch;
    QPolygon min_area_box;

public:
    explicit Draw(QWidget *parent = nullptr);
    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *e);
    void clearCH(){ch.clear(); repaint();}
    void clearPoints(){points.clear(); repaint();}
    QPolygon getPoints(){return points;}
    void setCH(QPolygon &hull){ch = hull;}
    void setPoints(QPolygon Points){points = Points;}
    QPolygon generateGrid(int n);
    QPolygon generateCircle(int n);
    QPolygon generateRandomPoints(int n);
    QPolygon generateEllipse(int n);
    QPolygon generateStarShape(int n);
    QPolygon generateSquare(int n);
    QPolygon getCH(){return ch;}
    void setMB(QPolygon &mb){min_area_box = mb;}


signals:

public slots:
};

#endif // DRAW_H
